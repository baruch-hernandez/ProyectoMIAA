# El administrador asigna el rol (Notificador o Administrador)

## Qué cambia
**Alta de empleado** (`/admin/empleados/nuevo`):
- Hay un selector de **rol**. Por defecto es Notificador.
- Al elegir Administrador sale una advertencia: un administrador puede ver todo y administrar a todos.
- El mensaje final dice dónde entra la persona: el panel web si es administrador, la app del celular si es notificador.

**Ficha del empleado:**
- Muestra el rol y se puede **cambiar** desde "Editar datos". El cambio aplica **al instante**, sin que la persona vuelva a iniciar sesión, porque el filtro JWT lee el rol de la base en cada petición.
- A los administradores no se les muestra el mapa (no comparten ubicación) ni el aviso de privacidad (solo aplica a notificadores).
- En **tu propia ficha** el selector de rol está bloqueado y no aparece "Dar de baja".

**Lista de empleados:** ahora salen notificadores **y** administradores; los administradores llevan una etiqueta.

## Candados (los pone el BACKEND, no solo la pantalla)
| Regla | Respuesta |
|---|---|
| Rol que no sea `ADMIN` o `NOTIFICADOR` | 400 |
| Cambiarte tu propio rol | 409 *"No puedes cambiar tu propio rol"* |
| Darte de baja a ti mismo | 409 |
| Quitarle el rol o dar de baja al **último** administrador activo | 409 *"Debe quedar al menos un administrador activo"* |

## Archivos
**Backend:**
- `dtos/NuevoEmpleadoDTO`, `EdicionEmpleadoDTO`: campo `rol`, opcional y validado.
- `dtos/CuentaEmpleadoDTO`, `EmpleadoDTO`: regresan el `rol`.
- `services/GestionEmpleadosService`: rol al crear y editar, los candados, y ya no filtra solo notificadores.
- `services/EmpleadoService`: la lista trae ambos roles.
- `services/UbicacionService`: la ficha de un admin ya no da 404.
- `controllers/UsuarioController`: pasa quién hace el cambio (`@AuthenticationPrincipal`) para los candados.
- `src/test/.../GestionEmpleadosServiceTest.java`: 10 pruebas con Mockito.

**Front:**
- `utils/roles.ts` y `components/admin/SelectorRol.tsx` (nuevos).
- `NuevoEmpleado.tsx`, `CuentaEmpleadoPanel.tsx`, `UbicacionEmpleado.tsx`, `EmpleadosAdmin.tsx` y `types/reporte.ts`.
- De paso, el texto "Mínimo 8 caracteres" del alta ahora dice 6, que es la regla real.

**Pruebas:** `pruebas/test_roles_empleados.py` va junto a las del punto 5: 5 de API y 2 con Selenium.

## Cómo probarlo
1. `.\mvnw test "-Dtest=*Test"` (JUnit, incluye las nuevas).
2. Backend + `npm run dev:https`. Da de alta a alguien como **Administrador** y entra con él: primero le pide crear su contraseña y luego llega al panel.
3. `cd pruebas` y `.\correr_pruebas.ps1`.

## Cómo se verificó
- **Front:** `tsc`, `eslint` y `vite build` limpios.
- **Backend:** el `GestionEmpleadosService` real se compiló y se probó con un repositorio falso en 15 casos, y todos pasan. Las pruebas de Mockito no se pudieron correr ahí (no hay acceso a Maven): confírmalas con el paso 1.
- **Suite completa:** pytest + Selenium (43 pasan y 1 se salta) contra su front real y un backend simulado con las mismas reglas.
